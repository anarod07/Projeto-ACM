from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def init_db(app):
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///discos.db'
    app.config['SECRET_KEY'] = 'secret_key'

    db.init_app(app)
    db.create_all()