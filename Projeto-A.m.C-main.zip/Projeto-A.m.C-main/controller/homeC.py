from flask import Blueprint, render_template, request, redirect, url_for, flash
from model import *

home_controller = Blueprint('home', __name__)

@home_controller.route('/')
def home():
    return render_template('home.html')

@home_controller.route('/artistas')
def artistas():
    return render_template('artistas.html')

@home_controller.route('/discos')
def discos():
    return render_template('discos.html')

 # Rota de Cadastro
@home_controller.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        nome = request.form['name']
        email = request.form['email']
        telefone = request.form['telefone']
        senha = request.form['password']

        # Criando o novo usuário
        novo_usuario = Usuario(nome=nome, email=email, telefone=telefone, senha=senha)
        
        try:
            db.session.add(novo_usuario)
            db.session.commit()
            return redirect(url_for('home_artistas'))  # Redireciona após o cadastro
        except Exception as e:
            db.session.rollback()
            return f"Erro ao cadastrar: {e}"
    
    return render_template('artistas.html')

@home_controller.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = Usuario.query.filter_by(email=email).first()
        if user and user.password == password:
            # login_user(user)  # Substituir por lógica própria
            flash('Login realizado com sucesso!', 'success')
            return redirect(url_for('home'))
        flash('Credenciais inválidas!', 'danger')
    return render_template('login.html')

@home_controller.route('/logout')
def logout():
    # logout_user()  # Substituir por lógica própria
    flash('Você saiu da sua conta!', 'info')
    return redirect(url_for('home'))
