from flask import Flask, Blueprint, render_template

login_controller = Blueprint('login', __name__)

#rota para página inicial
@login_controller.route('/login', methods = ['GET', 'POST'])
def login():
    return render_template("login.html")