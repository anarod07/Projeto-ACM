from flask import Flask, render_template
from model import db
from controller.homeC import home_controller
from database import init_db

app = Flask(__name__)

app.register_blueprint(home_controller)

# Função para lidar com erro 404 (página não encontrada)
@app.errorhandler(404)
def page_not_found(error):
    # Exibe a página '404.html' quando ocorre um erro 404
    return render_template('404.html'), 404

# Função para lidar com erro 500 (erro interno no servidor)
@app.errorhandler(500)
def erro_interno(error):
    # Exibe a página '500.html' quando ocorre um erro 500
    return render_template('500.html'), 500

if __name__ == '__main__':
    with app.app_context():
        init_db(app)
        app.run(debug=True)